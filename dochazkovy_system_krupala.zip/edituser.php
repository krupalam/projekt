<html>
	<head>
		<meta charset = "UTF-8">
		<title>Edit uživatele</title>
		<link href="css/edituser.css" media="all" rel="stylesheet">
	</head>
	<body>
<?php
header("Content-Type: text/html; charset=utf-8");

	// Create connection
	$conn = new mysqli("localhost", "root", "", "dochazkovysystem");
	
	// Check connection
	if ($conn->connect_error) 
	{
		die("Connection failed: " . $conn->connect_error);
	}
	else
	{
		$userID = $_POST["edit"];
		$sql = "SELECT * FROM users WHERE id=".$userID." LIMIT 1";
		$result = $conn->query($sql);
		if ($result->num_rows > 0) 
		{
			echo "<div class='vypis'>";
			echo "<table id='uzivatele'>";
			echo "<tr><th>ID: </th> <th>Jméno: </th> <th>Příjmení: </th> <th>Uživatelské jméno: </th> <th>Heslo: </th> <th> </th> <th> </th></tr>";
			while($row = $result->fetch_assoc()) 
			{
				$user = $row["id"]." ".$row["firstname"]." ".$row["secondname"]." ".$row["username"]." ".$row["password"]; 
			    echo "<form action='updateuser.php' method='POST'>" .				
					"<tr><td>" . $row["id"] . "</td>" .
					"<td> <input = type='text' name='firstname' value='". $row["firstname"] . "' ></td>" . 
					"<td> <input = type='text' name='secondname' value='". $row["secondname"] . "' ></td>" . 
					"<td> <input = type='text' name='username' value='". $row["username"] . "' ></td>" . 
					"<td> <input = type='text' name='password' value='". $row["password"] . "' ></td>" .
					"<td><button value=".$row["id"]." type='submit' name='save' id='save'>Ulož</button> </td> .
					</form>" . 
					"<form action='uzivatele.php' method='POST'>" .
					"<td><button value=".$row["id"]." type='submit' name='delete' id='delete'>Zpět</button> </td></tr>
					</form>";
					

					
				echo "<br>"; 
				
				echo "</th><td>";
			}
		}
		else
		{
			echo "Nepovedlo se uživatele načíst z databáze!";
			echo "<script>alert('PIN NEEXISTUJE !!'); window.location.href='uzivatele.php';</script>";
			exit;
		}
		
		
	}
	mysqli_close($conn);
?>

	</body>
</html>


