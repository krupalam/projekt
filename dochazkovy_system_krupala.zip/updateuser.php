<!DOCTYPE html>
<html>
<head>
	<meta charset = "UTF-8">
	<title> Docházkový systém </title>
</head>
<body>
	<?php
	// POST variables from edit.php
	$UserID         = $_POST["save"];
	$firstname      = $_POST["firstname"];
	$secondname     = $_POST["secondname"];
	$username       = $_POST["username"];
	$password       = $_POST["password"];
	// Create connection
	$conn = new mysqli("localhost", "root", "", "dochazkovysystem");
	
	// Check connection
	if ($conn->connect_error) 
	{
		die("Connection failed: " . $conn->connect_error);
	}
	else
	{   // vytvoření SQL dotazu
		$sql =   "UPDATE users SET firstname='".$firstname."', secondname='".$secondname."', username='".$username."', password='".$password."' WHERE id='".$UserID."'";
		// vykonání příkazu query
		if ($conn->query($sql) === TRUE) 
		{ 
			echo $sql;
			echo "<script>alert('Data uživatele byla aktualizována!'); window.location.href='uzivatele.php';</script>";
		} 
		else 
		{
			echo "Error: " . $sql . "<br>" . $conn->error;
			echo "<script>alert('Uživatele se nepovedlo aktualizovat!'); window.location.href='uzivatele.php';</script>";
			exit;
		}	
	
			
	$conn->close();
	}
	?>
</body>
</html>


"UPDATE users WHERE id=".$userID." VALUES (null,'$firstname', '$secondname', '$username', '$password')";