<!DOCTYPE html>
<html>
<head>
	<meta charset = "UTF-8">
	<title> Docházkový systém </title>
</head>
<body>
	<?php
	// postované proměnné z uzivatele.php
	$firstname      = $_POST["firstname"];
	$secondname     = $_POST["secondname"];	
	$username       = $_POST["username"];
	$password       = $_POST["password"];	

	// Create connection
	$conn = new mysqli("localhost", "root", "", "dochazkovysystem");
	
	// Check connection
	if ($conn->connect_error) 
	{
		die("Connection failed: " . $conn->connect_error);
	}
	else
	{   // vytvoření SQL dotazu
		$sql = "INSERT INTO users (id, firstname, secondname, username, password)
				VALUES (null,'$firstname', '$secondname', '$username', '$password')"; 
		// vykonání příkazu query
		if (($firstname <> "") && ($secondname <> "" ) && ($username <> ""))	
		{
			if ($conn->query($sql) === TRUE) 
			{ 
				echo $sql;
				echo "<script>alert('Nový uživatel vytvořen'); window.location.href='uzivatele.php';</script>";
			} 
			else 
			{
				echo "Error: " . $sql . "<br>" . $conn->error;
				echo "<script>alert('Nový uživatel nebyl vytvořen'); window.location.href='uzivatele.php';</script>";
				exit;
			}
		}
		else
		{
			echo "<script>alert('Nový uživatel nebyl řádně vyplněn!'); window.location.href='uzivatele.php';</script>";
			exit;
		}
			
	
			
	$conn->close();
	}
	?>
</body>
</html>