<html>
	<head>
		<meta charset = "UTF-8">
		<title></title>
		<link href="css/zpracovani.css" media="all" rel="stylesheet">	
	</head>
	<body>
<?php
header("Content-Type: text/html; charset=utf-8");

	// Create connection
	$conn = new mysqli("localhost", "root", "", "dochazkovysystem");
	
	// Check connection
	if ($conn->connect_error) 
	{
		die("Connection failed: " . $conn->connect_error);
	}
	else
	{
		if(isset($_POST["passwd"]) && isset($_POST["akce"])&& isset($_POST["user"]))
		{
			$jmeno;
			$person  = $_POST["user"];
			$passwd  = $_POST["passwd"];
			$akce    = $_POST["akce"];
			$akcetyp = 0;
			$time    = Time();
			
			if(is_numeric("$passwd"))
			{
				$sql = "SELECT  firstname, secondname FROM users WHERE password='".$passwd."' AND username='".$person."' LIMIT 1 ";
				$result = $conn->query($sql);
				if ($result->num_rows > 0) 
				{
				  while($row = $result->fetch_assoc()) 
				  {
					$jmeno  = $row["firstname"]." ".$row["secondname"];
					echo "<br>";
				  }
				}
				else
				{
					echo "Není vyplněno přihlašovací jméno nebo heslo !";
					echo "<script>alert('Není vyplněno přihlašovací jméno nebo heslo, nebo uživatel neexistuje!'); window.location.href='index.php';</script>";
					exit;
				}

			}
			else
			{
				echo "V hesle nyní nejsou povoleny nečíselné znaky nebo nebylo vyplněno!";
				echo "<script>alert('V hesle nyní nejsou povoleny nečíselné znaky nebo nebylo vyplněno!'); window.location.href='index.php';</script>";
				exit;
			}
			if($jmeno == "")
			{
				echo "Heslo je špatně zadáno!";
				echo "<script>alert('Heslo je špatně zadáno!'); window.location.href='index.php';</script>";
				exit;
			}
			echo "<div class='container'>";
			echo "<table><tr><th>Jméno: </th><td>" . $jmeno . "</td></tr>";
			echo "<tr><th>Čas: </th><td>" .  Date ("d. n. Y, H:i:s", $time) . "</td></tr>";
			echo "<tr><th>Typ přihlášení: </th><td>";
			
			if($akce == "prichod")
			{
				echo "Příchod"; $akcetyp=1;
			}
			elseif ($akce == "odchod")
			{
				echo "Odchod"; $akcetyp=0;
			}
			elseif ($akce == "lekar")
			{
				echo "Lékař"; $akcetyp=2;
			}

			elseif ($akce == "prestavka")
			{
				echo "Přestávka"; $akcetyp=3;
			}
			else
			{
				echo "Odchod"; $akcetyp=0;
			}
		
			echo "</td></tr></table></div>";
			$sql = "INSERT INTO records VALUES (null, '".$person."', ".$akcetyp.", ".$time.")";	
			
			

			if (mysqli_query($conn, $sql)) 
			{
				$aakce = "odhlášen";
				if($akce == "prichod")
				{
					$aakce = "přihlášen";
				}
					echo "<script type=\"text/javascript\">        
							window.setTimeout(function() {
								window.location.replace('index.php');
							}, 5000);
							</script>";
				
			} 
			else 
			{
				echo "Chyba databáze";
			}
		}
	}
	mysqli_close($conn);
//	echo "<div class='container'>";
//echo $sql;
//echo "</div>";
?>

	</body>
</html>


