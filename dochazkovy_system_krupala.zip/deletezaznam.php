<!DOCTYPE html>
<html>
<head>
	<meta charset = "UTF-8">
	<title> Docházkový systém </title>
</head>
<body>
	<?php
	// přihlášení k DB a výpis všech uživatelů
	$servername = "localhost";
	$usrname    = "root";
	$password   = "";
	$db 	    = "dochazkovysystem";
	// postované proměnné z edit.php
	$zaznamID      = $_POST["delete"];
	
	// Create connection
	$conn = new mysqli($servername, $usrname, $password, $db);
	
	// Check connection
	if ($conn->connect_error) 
	{
		die("Connection failed: " . $conn->connect_error);
	}
	else
	{   // vytvoření SQL dotazu
		$sql = "DELETE FROM records WHERE id = '$zaznamID'"; 
		// vykonání příkazu query
		if ($conn->query($sql) === TRUE) 
		{ 
			echo $sql;
			echo "<script>alert('Vybraný záznam byl smazán!'); window.location.href='uzivatele.php';</script>";
		} 
		else 
		{
			echo "Error: " . $sql . "<br>" . $conn->error;
			echo "<script>alert('Záznam se nepovedlo smazat!'); window.location.href='uzivatele.php';</script>";
			exit;
		}	
	
			
	$conn->close();
	}
	?>
</body>
</html>