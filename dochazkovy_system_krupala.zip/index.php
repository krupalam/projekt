<!DOCTYPE html>
<html>
	<head>
		<meta charset = "UTF-8">
		<title> Docházkový systém </title>
		<link href="css/index.css" media="all" rel="stylesheet">
	</head>
	<body>		
		<button onclick="myFunctionHide()">Odkrýt/zakrýt klávesnici</button><br>
		<form action="zpracovani.php" method="POST">
			<label for="user">Vlož uživatelské jméno: </label><br>
			<input type="text" name="user" id="user"><br>
			<label for="passwd">Vlož PIN: </label><br>
			<input type="password" name="passwd" id="passwd"><br><br>
			<div id="klavesniceDIV">
			<span class='klavesnice'>
				<!-- Javascriptova klavesnice pro dotykovy display -->
				<button onClick="document.getElementById('passwd').value += 1; return false">1</button>
				<button onClick="document.getElementById('passwd').value += 2; return false">2</button>
				<button onClick="document.getElementById('passwd').value += 3; return false">3</button>
				<button onClick="document.getElementById('passwd').value += 4; return false">4</button>
				<button onClick="document.getElementById('passwd').value += 5; return false">5</button>
				<button onClick="document.getElementById('passwd').value += 6; return false">6</button>
				<button onClick="document.getElementById('passwd').value += 7; return false">7</button>
				<button onClick="document.getElementById('passwd').value += 8; return false">8</button>
				<button onClick="document.getElementById('passwd').value += 9; return false">9</button>
				<button onClick="document.getElementById('passwd').value += 0; return false">0</button><br>
			</span>
			
			<span class='klavesniceqwertz'>
				<button onClick="document.getElementById('user').value += 'q'; return false">q</button>
				<button onClick="document.getElementById('user').value += 'w'; return false">w</button>
				<button onClick="document.getElementById('user').value += 'e'; return false">e</button>
				<button onClick="document.getElementById('user').value += 'r'; return false">r</button>
				<button onClick="document.getElementById('user').value += 't'; return false">t</button>
				<button onClick="document.getElementById('user').value += 'z'; return false">z</button>
				<button onClick="document.getElementById('user').value += 'u'; return false">u</button>
				<button onClick="document.getElementById('user').value += 'i'; return false">i</button>
				<button onClick="document.getElementById('user').value += 'o'; return false">o</button>
				<button onClick="document.getElementById('user').value += 'p'; return false">p</button><br>
				<button onClick="document.getElementById('user').value += 'a'; return false">a</button>
				<button onClick="document.getElementById('user').value += 's'; return false">s</button>
				<button onClick="document.getElementById('user').value += 'd'; return false">d</button>
				<button onClick="document.getElementById('user').value += 'f'; return false">f</button>
				<button onClick="document.getElementById('user').value += 'g'; return false">g</button>
				<button onClick="document.getElementById('user').value += 'h'; return false">h</button>
				<button onClick="document.getElementById('user').value += 'j'; return false">j</button>
				<button onClick="document.getElementById('user').value += 'k'; return false">k</button>
				<button onClick="document.getElementById('user').value += 'l'; return false">l</button><br>
				<button onClick="document.getElementById('user').value += 'y'; return false">y</button>
				<button onClick="document.getElementById('user').value += 'x'; return false">x</button>
				<button onClick="document.getElementById('user').value += 'c'; return false">c</button>
				<button onClick="document.getElementById('user').value += 'v'; return false">v</button>
				<button onClick="document.getElementById('user').value += 'b'; return false">b</button>
				<button onClick="document.getElementById('user').value += 'n'; return false">n</button>
				<button onClick="document.getElementById('user').value += 'm'; return false">m</button>
			</span>
			</div>
			
		<button class="akce" value="prichod" name="akce">Příchod</button>
		<button class="akce" value="odchod" name="akce">Odchod</button>
		<button class="akce" value="lekar" name="akce">K lékaři</button>
		<button class="akce" value="prestavka" name="akce">Přestávka</button><br>
		<button class="clean" onClick="document.getElementById('user').value = ''; return false">reset přihlášení</button><br>
		<button class="clean" onClick="document.getElementById('passwd').value = ''; return false">reset heslo</button><br>
		</form>
		
		<form action="adminprelogin.php" method="POST">
		<button class="admin">přihlášení administrátora</button><br>
		</form>
		
			
	</body>
	
<script>
function myFunctionHide() {
  var x = document.getElementById("klavesniceDIV");
  if (x.style.display === "none") {
    x.style.display = "block";
  } else {
    x.style.display = "none";
  }
}
	
</script>
</html>
	
	
	