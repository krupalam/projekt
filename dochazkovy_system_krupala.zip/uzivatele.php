<html>
<head>
	<meta charset = "UTF-8">
	<title>Administrátor</title>
	<link href="css/uzivatele.css" media="all" rel="stylesheet">
</head>
<body>


	
<?php
	// Create connection
	$conn = new mysqli("localhost", "root", "", "dochazkovysystem");
	
	// Check connection
	if ($conn->connect_error) 
	{
		die("Connection failed: " . $conn->connect_error);
	}
	else
	{
		$sql = "SELECT * FROM users WHERE id>'0'"; 
		$result = $conn->query($sql);
		if ($result->num_rows > 0) 
		{
			echo "<div class='list'>";
			echo "<table id='users'>";
			echo "<tr><th>ID: </th> <th>Jméno: </th> <th>Příjmení: </th> <th>Uživatelské jméno: </th> <th>Heslo: </th> <th>Editovat </th> <th>Smazat </th> <th>Docházka </th></tr>";
			// výpis tabulky všech existujicích uživatelů
			while($row = $result->fetch_assoc()) 
			{
				$user = $row["id"]." ".$row["firstname"]." ".$row["secondname"]." ".$row["username"]." ".$row["password"]; 			
                echo "<tr><td>" . $row["id"] . "</td>" .
					 "<td>" . $row["firstname"] . "</td>" . 
					 "<td>" . $row["secondname"] . "</td>" . 
					 "<td>" . $row["username"] . "</td>" . 
					 "<td>" . $row["password"] . "</td>" .
					 "<form action='edituser.php' method='POST'>" .
					 "<td><button value=".$row["id"]." type='submit' name='edit' id='edit'>Editovat</button> </td>" .
					 "</form>" .
					 "<form action='deleteuser.php' method='POST'>" .
					 "<td><button value=".$row["id"]." type='submit' name='delete' id='delete'>Vymazat</button> </td>
					 </form>" .
					 "<form action='dochazka.php' method='POST'>" .
					 "<td><button value=".$row["username"]." type='submit' name='dochazka' id='dochazka'>Docházka</button> </td></tr>
					 </form>";
				 
				
				echo "</th><td>";
				
			}
			// možnost vložit nového uživatele
			echo "<form action='newuser.php' method='POST'>
				 <span class = 'newuser'>
				 <td><input type='text' name='firstname' id='firstname'></td>  
				 <td><input type='text' name='secondname' id='secondname'></td> 
				 <td><input type='text' name='username' id='username'></td> 
				 <td><input type='text' name='password' id='password'></td> 					
				 <td><button type='submit' name='New' id='New'>Nový</button> </td>
				 </span>
				 </form>";
			echo "<br>"; 
			echo "</div>";
			echo "</table>";
		}
		else
		{
			echo "<script>alert('Uživatel nenalezen!'); window.location.href='index.php';</script>";
			exit;
		}
		echo "<a class='btn' href='index.php'>Zpět</a>";
	}
	
?>	
	
</body>
</html>