<div class="admin" id="admin">
	<form action="adminlogin.php" method="POST">
		<span class = 'AdminLogin'>
			<table class='adminTable'>
				<tr><td><label for="adminJmeno">Admin:</label></td>
				<td><input type="text" name="adminJmeno" id="adminJmeno"></td></tr><br><br>
				<tr><td><label for="adminPass">Heslo:</label></td>
				<td><input type="password" name="adminPass" id="adminPass"></td><br><br>
				<td><button class="AdminLogin" type="submit">Login</button></td></tr>
			</table>
		</span>
	</form>
</div>