<html>
<head>
	<meta charset = "UTF-8">
	<title>Administrátor</title>
	<link href="css/dochazka.css" media="all" rel="stylesheet">
</head>
<body>


	
<?php
// přihlášení k DB a výpis všech uživatelů
	
	
	// Create connection
	$conn = new mysqli("localhost", "root", "", "dochazkovysystem");
	$UserID      = $_POST["dochazka"];
	$druhZaznamu;
	// Check connection
	if ($conn->connect_error) 
	{
		die("Connection failed: " . $conn->connect_error);
	}
	else
	{
		// výpis jména z tabulky uzivatelu
		$sql2 = "SELECT firstname, secondname FROM users WHERE username='".$UserID."' ";
		$result2 = $conn->query($sql2);
		if ($result2->num_rows > 0) 
		{		
			while($row2 = $result2->fetch_assoc()) 
			{
				$zaznam2 = $row2["firstname"]." ".$row2["secondname"].""; 
			}
		}
		else
		{
			echo "<script>alert('Uživatel nebyl nalezen!'); window.location.href='uzivatele.php';</script>";
			exit;
		}
		// vypis zaznamu tabulky
		$sql = "SELECT * FROM records WHERE person='".$UserID."' ";
		$result = $conn->query($sql);
		if ($result->num_rows > 0) 
		{
			echo "<div class='vypis'>";
			echo "<table id='uzivatele'>";
			echo "<tr><th>ID záznamu: </th> <th>Uživatel: </th> <th>Druh záznamu: </th> <th>Čas: </th> <th>Smazat záznam: </th></tr>";
			// výpis tabulky všech existujicích uživatelů
			while($row = $result->fetch_assoc()) 
			{
				$zaznam = $row["id"]." ".$row["person"]." ".$row["typerecord"]." ".$row["time"].""; 
				if ($row["typerecord"]==1)
				{
					$typerecord = 'Příchod';
				}
				elseif ($row["typerecord"]==2)
				{
					$typerecord = 'Lékař';
				}
				elseif ($row["typerecord"]==3)
				{
					$typerecord = 'Přestávka';
				}
				else
				{
					$typerecord = 'Odchod';
				}
                echo "<tr><td>" . $row["id"] . "</td>" .
					 "<td>" . $zaznam2 . "</td>" . 
					 "<td>" . $typerecord . "</td>" . 
					 "<td>" . Date ("d. n. Y, H:i:s", $row["time"]) . "</td>" . 							
					 "<form action='deletezaznam.php' method='POST'>" .
					 "<td><button value=".$row["id"]." type='submit' name='delete' id='delete'>Delete</button> </td></tr>
					 </form>";
				
				echo "</th><td>";
				
			}
			echo "<br>"; 
			echo "</div>";
			echo "</table>";
		}
		else
		{
			echo "<script>alert('Docházka uživatele neexistuje!'); window.location.href='uzivatele.php';</script>";
			exit;
		}
				echo "<a class='btn' href='uzivatele.php'>Zpět</a>";	
	}	
?>	
	
</body>
</html>