<html>
<head>
	<meta charset = "UTF-8">
	<title>Kontrola admin přihlášení</title>
	<style>
		.container
			{
				width: 100%;
				top: 40%;
				position: absolute;
				text-align: center;
				font: Calibri;
				font-size: 35px;
				background-color: #F0BB97;
			}
	</style>
</head>
<body>
<?php
header("Content-Type: text/html; charset=utf-8");
	// Create connection
	$conn = new mysqli("localhost", "root", "", "dochazkovysystem");
	
	// Check connection
	if ($conn->connect_error) 
	{
		die("Connection failed: " . $conn->connect_error);
	}
	else
	{
		$login;
		$adminName = $_POST["adminJmeno"];
		$pass      = $_POST["adminPass"];
		
		if(($adminName <> "") && ($pass <> ""))
		{
				$sql = "SELECT username, password FROM users WHERE username='".$adminName."' AND id ='1' LIMIT 1"; 
				$result = $conn->query($sql);
				if ($result->num_rows > 0) 
				{
				  while($row = $result->fetch_assoc()) 
				  {
					$login = $row["username"]." ".$row["password"];
					if ( $row["password"] == $pass )
					{  // if password is OK
						echo "<div class='container'>"; /////// continue
						echo "Admin login OK!<br>";
						echo "</div>";
						echo  "<script type=\"text/javascript\">      
							window.setTimeout(function() {
								window.location.replace('uzivatele.php');
							}, 2000);
							</script>";						
					}
					else
					{
						echo "<div class='container'>"; /////// continue
						echo "Zadali jste špatně heslo!<br>";
						echo "</div>";
						echo  "<script type=\"text/javascript\">      
							window.setTimeout(function() {
								window.location.replace('adminprelogin.php');
							}, 4000);
							</script>";
					}
				  }
				}
				else
				{
					echo "<div class='container'>"; /////// continue
						echo "Uživatel nenalezen nebo není admin!<br>";
						echo "</div>";
						echo  "<script type=\"text/javascript\">      
							window.setTimeout(function() {
								window.location.replace('adminprelogin.php');
							}, 4000);
							</script>";
					exit;
				}
				
		}
		else
		{
			echo "Není vyplněno jméno nebo heslo";
			echo "<script>alert('Není vyplněno jméno nebo heslo!!'); window.location.href='index.php';</script>";
			exit;
		}
	}
	
//přihlášení administrátora




?>

</body>
</html>